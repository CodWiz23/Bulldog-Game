/**
 * 
 * The Unique Player class extends the abstract player class. In this class, I adjusted the rules of bulldog
 * to be similar to blackjack. The user cannot exceed 21 in points but can choose to play as many rounds as they want.
 * Once the user rolls a 6 they lose their points and their turn. If they exceed 21 they lose their turn and points. To win you must get 
 * 21 and not roll a 6 in one try.
 * 
 * @version Jan 29, 2025
 * @author abdirahman
 */
public class UniquePlayer extends Player {

	public UniquePlayer() {
		this("UPlayer");
	}

	public UniquePlayer(String name) {
		super(name);
	}

	@Override
	public int play() {
		int turnScore = 0;
		while(true) {
			int roll = (int) (Math.random() * 6 + 1); // Roll a six-sided die
			System.out.println(getName() + " rolled " + roll);

			if (roll == 6) {
				System.out.println("Womp Womp Womp...you lose all your points from this turn. Better luck next time!");
				System.out.println(getName() + "'s score: " + turnScore);
				return 0; // End the turn with a score of 0
			}
			if(turnScore + roll > 21) {
				System.out.println("Womp Womp Womp...you lose all your points from this turn. Better luck next time!");
				System.out.println(getName() + "'s score: " + turnScore);
				return 0; // End the turn with a score of 0
			}
			if(turnScore + roll == 21){
				turnScore += roll;
				System.out.println("Your turn is over for this round.");
				return turnScore;
			}else {
				turnScore += roll;
				System.out.println("Current Score: " + turnScore);

			}


		}
	}

}
