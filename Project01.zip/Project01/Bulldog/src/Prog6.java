import java.util.Scanner; 

/**
 * Prog6 - The main class for the Bulldog Game. 
 * This program allows a user to select a player profile and play a turn-based game.
 * The user can choose from various player types, each with unique gameplay strategies/rules.
 */
public class Prog6 {

    /**
     * The main method is the entry point of the program.
     * It manages user interaction, game initialization, and gameplay flow.
     * 
     * @param args Command-line arguments (not used in this program).
     */
    public static void main(String[] args) {

        // Create the scanner that will interact with the user
        Scanner gameUser = new Scanner(System.in);

        // Welcome messages
        System.out.println("Welcome to the Bulldog Game!");
        System.out.println("It is time to get you registered!");
        gameUser.nextLine(); // Pause for user input

        // Ask the user to input their name
        System.out.println("Enter your name: ");
        String playerName = gameUser.next(); // Read player's name

        // Ask the user to pick their desired player profile
        System.out.println("Insert a number that corresponds to your desired player profile:"
                + "\n1. FPlayer\n2. UPlayer\n3. WPlayer\n4. HPlayer\n5. RPlayer");

        int choice = gameUser.nextInt(); // Read the player's choice
        gameUser.nextLine(); // Clear the input buffer
        int result = 0; // Initialize the result variable

        // Determine the player's choice and initialize the appropriate player type
        if (choice == 1) {
            Player player = new FifteenPlayer(playerName); // FifteenPlayer type
            result = player.play();
        } else if (choice == 2) {
            Player player2 = new UniquePlayer(playerName); // UniquePlayer type
            result = player2.play();
        } else if (choice == 3) {
            Player player3 = new WimpPlayer(playerName); // WimpPlayer type
            result = player3.play();
        } else if (choice == 4) {
            Player player4 = new HumanPlayer(playerName); // HumanPlayer type
            result = player4.play();
        } else if (choice == 5) {
            Player player5 = new RandomPlayer(playerName); // RandomPlayer type
            result = player5.play();
        } else {
            // Handle invalid input
            System.out.println("Invalid choice! Defaulting to HumanPlayer.");
            Player playerDefault = new HumanPlayer(playerName);
            result = playerDefault.play();
        }

        // Display the player's final score
        System.out.println("Your final score is " + result);

        // Ask the user if they want to play again
        System.out.print("Dare to play again??? (yes/no): ");
        String response = gameUser.nextLine(); // Read the player's response

        if (response.equalsIgnoreCase("yes")) {
            // Restart the game
            System.out.println("\nRestarting the game...\n");
            main(args); // Recursive call to main 
        } else {
            // End the game
            System.out.println("Thank you for playing the Bulldog Game, " + playerName + "!");
            gameUser.close(); // Close the scanner
        }
    }
}
